[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Rt1-Sh63)
<h2 align="center">CSCE 2211 Fall 2024 Applied Data Structures</h2>
<h3 align="center">Assignment 6</h3>

> [!NOTE]  
> This is a Bonus (Optional) assignment. Its maximum grade will count as 2.5% of the total course grade. No submissions will be accepted after the due date.

> [!IMPORTANT]  
> Avoid deduction by writing your name, section number, and ID in comment at the beginning of each file, then push your changes. 📝

<table border="0">
 <tr>
    <td><b style="font-size:20px">📋 Prerequisites for the Assignment</b></td>
 </tr>
 <tr>
    <td>
    1. Create a <a href="https://account.jetbrains.com/login" target="_blank">JetBrains Account</a> & apply for the student pack. 🎓<br>    
    2. Download <a href="https://www.jetbrains.com/clion/download/#section=mac" target="_blank">CLion for Windows & Mac</a> and sign in with your account. 💻<br>    
    3. Sign in to the GitHub Desktop app on your PC. 🔗<br>  
    4. Clone this repository to start working on the assignment. 📂<br>
    5. Write your name and ID in a comment at the beginning of each file, then push your changes. 📝<br>
    </td>
 </tr>
</table>

## 🔍 Overview of the Assignment
#### Finding all pairs shortest paths in a weighted graph

We have a map of airports and the flights that connect them to one another. Such a network of flights can be represented by a graph with N vertices and the weights on the edges represent the cost of traveling between the the pairs of airports. An Excel sheet “Airports14.xlsx” gives the adjacency matrix representation for such weighted graph for N = 14 airports. The graph is connected, and the weights are all positive integers in the range 20 - 100. Zero weights represent the absence of a direct flight, or the cost of traveling between an airport and itself. The airports are simply named (A, B, C, ...).

![All-Pairs Shortest Paths](https://sites.cs.ucsb.edu/~gilbert/cs140/old/cs140Win2010x/cudaproject/apsp-graph.png)

## 🔨 Required Implementation

Develop a program to:
- Traverse the given graph using the DFS algorithm.
- Determine the All-Pairs shortest paths in the given graph using Floyd’s dynamic programming algorithm.

### 📬 Submission Instructions:
- All C++ documentation.
- Comment on on your code and document any assumptions you made.
- Output results for the graph given in "[Airports14.xlsx](Airports14.xlsx)"

There is also a test graph file “[TestG.xlsx](TestG.xlsx)” representing a graph of 7 vertices. You can test your implementation using this file. The sample output for that file is also given in file “[Sample.txt](Sample.txt)”.

📝 To-Do List
- [ ] Commit and push your code regularly to GitHub.
- [ ] Submit your final code before the deadline (December 9th, 2024, 11:59 CLT).

:white_check_mark: Use `git status` to list all new or modified files that haven't yet been committed.

<p align="center">
  <b>Created by</b><br>
  <b>Mohamed Ibrahim Hany</b>
</p>
