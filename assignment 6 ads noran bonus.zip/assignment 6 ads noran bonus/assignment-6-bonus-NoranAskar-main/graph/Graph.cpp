/********************************************************************************
* WARNING: Please do not remove or modify this comment block.
 *
 * Student Information:
 * Name: Nour Waleed
 * Student ID: 900211139
 * Section Number: 03
 *
 ********************************************************************************/

#include "Graph.h"

#include <iostream>
#include <iomanip>
using namespace std;

Graph::Graph() = default;

Graph::Graph(const string& excelPath) {
    excelDoc.suppressWarnings();

    try {
        excelDoc.open(excelPath);
        if (!excelDoc.isOpen()) {
            cerr << "Error opening file " << excelPath << endl;
            return;
        }

        XLWorkbook workbook = excelDoc.workbook();
        XLWorksheet sheet = workbook.worksheet("Sheet1");

        for (int i = 3; i <= sheet.rowCount(); i++) {
            adjMatArr.emplace_back();
            for (int j = 2; j <= sheet.columnCount(); j++) {
                adjMatArr[i - 3].push_back(sheet.cell(i, j).value().get<int>());
            }
        }

        excelDoc.close();
    } catch (exception& e) {
        cerr << "Error: " << e.what() << endl;
    }
}

vector<vector<int>> Graph::getAdjacencyMatrix() {
    return adjMatArr;
}

int Graph::getVertexCount() {
    return adjMatArr.size();
}

int Graph::getEdgeCount() {
    int count = 0;

    for (int i = 0; i < adjMatArr.size(); i++) {
        for (int j = i + 1; j < adjMatArr[i].size(); j++) {
            if (adjMatArr[i][j] != 0) {
                count++;
            }
        }
    }

    return count;
}

void Graph::DFS(int sourceVertex) {
    if (sourceVertex >= getVertexCount()) {
        cout << "Error: Source vertex out of range!" << endl;
        return;
    }

    cout << "DFS Traversal" << endl;

    vector<bool> visited(adjMatArr.size(), false);
    DFSTraverse(visited, sourceVertex);

    cout << endl << endl;
}

void Graph::DFSTraverse(vector<bool>& visited, int sourceVertex) {
    visited[sourceVertex] = true;

    cout << setw(5) << sourceVertex + 1 << " " << static_cast<char>(
        'A' + sourceVertex);

    for (int i = 0; i < adjMatArr[sourceVertex].size(); i++) {
        if (!visited[i]) {
            DFSTraverse(visited, i);
        }
    }
}

void Graph::printAdjacencyMatrix() {
    cout << "Adjacency Matrix" << endl;

    cout << setw(8) << "";
    for (int i = 0; i < adjMatArr.size(); i++) {
        cout << setw(8) << static_cast<char>('A' + i);
    }
    cout << endl;

    for (int i = 0; i < adjMatArr.size(); i++) {
        cout << setw(8) << static_cast<char>('A' + i);
        for (int j = 0; j < adjMatArr[i].size(); j++) {
            cout << setw(8) << adjMatArr[i][j];
        }
        cout << endl;
    }

    cout << endl;
}

void Graph::printEdges() {
    cout << "Graph Edges" << endl;

    for (int i = 0; i < adjMatArr.size(); i++) {
        for (int j = i + 1; j < adjMatArr[i].size(); j++) {
            if (adjMatArr[i][j] != 0) {
                cout << setw(5) << static_cast<char>('A' + i) << ' ';
                cout << setw(5) << static_cast<char>('A' + j) << ' ';
                cout << setw(5) << adjMatArr[i][j] << endl;
            }
        }
    }

    cout << endl;
}
