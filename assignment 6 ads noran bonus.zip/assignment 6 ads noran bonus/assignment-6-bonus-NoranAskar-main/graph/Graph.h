/********************************************************************************
* WARNING: Please do not remove or modify this comment block.
 *
 * Student Information:
 * Name: Nour Waleed
 * Student ID: 900211139
 * Section Number: 03
 *
 ********************************************************************************/

#ifndef GRAPH_H
#define GRAPH_H

#include <OpenXLSX.hpp>
using namespace OpenXLSX;

#include <vector>
#include <string>
using namespace std;

class Graph
{
private:
    vector<vector<int>> adjMatArr;
    XLDocument excelDoc;

    // A helper function to do the depth-first traversal
    void DFSTraverse(vector<bool>& visited, int sourceVertex);

public:
    // Default Constructor
    Graph();

    // A parameterized constructor that takes the path of xlsx file as a parameter providing an adjacency matrix for the graph
    explicit Graph(const string& xlsxPath);

    // Gets the adjacency matrix of the graph
    vector<vector<int>> getAdjacencyMatrix();

    // Gets the number of vertices in the graph
    int getVertexCount();

    // Gets the number of edges in the graph
    int getEdgeCount();

    // A function to do a depth-first search on the graph
    void DFS(int sourceVertex);

    // Prints the adjacency matrix of the graph
    void printAdjacencyMatrix();

    // Prints the edges of the graph
    void printEdges();
};


#endif //GRAPH_H
