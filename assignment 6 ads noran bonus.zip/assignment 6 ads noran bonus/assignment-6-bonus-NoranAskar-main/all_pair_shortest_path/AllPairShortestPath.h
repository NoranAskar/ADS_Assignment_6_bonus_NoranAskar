/********************************************************************************
* WARNING: Please do not remove or modify this comment block.
 *
 * Student Information:
 * Name:Nour Waleed
 * Student ID: 900211139
 * Section Number: 03
 *
 ********************************************************************************/

#ifndef ALLPAIRSHORTESTPATH_H
#define ALLPAIRSHORTESTPATH_H

#include <Graph.h>

class AllPairShortestPath
{
private:
    vector<vector<int>> shortestPathArr;
    vector<vector<int>> nextNodeInPath;

    // A helper function to run the Floyd-Warshall algorithm on the graph
    void calculateShortestPath();

    // A helper function to construct the path between two nodes
    void constructPath(vector<int>& pathArr, int node1, int node2);

public:
    AllPairShortestPath();

    // A parameterized constructor that takes a graph as a parameter
    explicit AllPairShortestPath(Graph& graph);

    // Prints a matrix with the shortest path for each pair
    void printAllPairShortestPath();

    // Prints the shortest paths from a single source vertex
    void printVertexShortestPath(int sourceVertex);

    // Prints the next nodes matrix used to construct paths
    void printNextNodeMatrix();
};


#endif //ALLPAIRSHORTESTPATH_H
