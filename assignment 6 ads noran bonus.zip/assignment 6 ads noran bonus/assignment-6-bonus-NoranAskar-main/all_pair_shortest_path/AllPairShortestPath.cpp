/********************************************************************************
* WARNING: Please do not remove or modify this comment block.
 *
 * Student Information:
 * Name: Nour Waleed
 * Student ID: 900211139
 * Section Number: 03
 *
 ********************************************************************************/

#include "AllPairShortestPath.h"
#include <Graph.h>
#include <iomanip>
#include <vector>
using namespace std;

#define INF 999 // Could be any number > 100 as per the problem statement of the assignment



AllPairShortestPath::AllPairShortestPath() = default;

AllPairShortestPath::AllPairShortestPath(Graph& graph) {
    shortestPathArr.resize(graph.getAdjacencyMatrix().size());
    nextNodeInPath.resize(graph.getAdjacencyMatrix().size());

    for (int i = 0; i < shortestPathArr.size(); i++) {
        shortestPathArr[i].resize(graph.getAdjacencyMatrix()[i].size());
        nextNodeInPath[i].resize(graph.getAdjacencyMatrix()[i].size());
    }

    for (int i = 0; i < graph.getAdjacencyMatrix().size(); i++) {
        for (int j = 0; j < graph.getAdjacencyMatrix()[i].size(); j++) {
            if (i == j) {
                shortestPathArr[i][j] = 0;
                nextNodeInPath[i][j] = 0;
            } else if (graph.getAdjacencyMatrix()[i][j] == 0) {
                shortestPathArr[i][j] = INF;
                nextNodeInPath[i][j] = INF;
            } else {
                shortestPathArr[i][j] = graph.getAdjacencyMatrix()[i][j];
                nextNodeInPath[i][j] = j;
            }
        }
    }

    calculateShortestPath();
}

void AllPairShortestPath::calculateShortestPath() {
    for (int k = 0; k < shortestPathArr.size(); k++) {
        for (int i = 0; i < shortestPathArr.size(); i++) {
            for (int j = 0; j < shortestPathArr.size(); j++) {
                if (shortestPathArr[i][j] > shortestPathArr[i][k] +
                    shortestPathArr[k][j]) {
                    shortestPathArr[i][j] =
                        shortestPathArr[i][k] + shortestPathArr[k][j];
                    nextNodeInPath[i][j] = nextNodeInPath[i][k];
                }
            }
        }
    }
}

void AllPairShortestPath::printAllPairShortestPath() {
    cout << "All-Pairs Shortest Paths" << endl;

    cout << setw(8) << "";
    for (int i = 0; i < shortestPathArr.size(); i++) {
        cout << setw(8) << static_cast<char>('A' + i);
    }
    cout << endl;

    for (int i = 0; i < shortestPathArr.size(); i++) {
        cout << setw(8) << static_cast<char>('A' + i);
        for (int j = 0; j < shortestPathArr[i].size(); j++) {
            cout << setw(8) << shortestPathArr[i][j];
        }
        cout << endl;
    }

    cout << endl;
}

void AllPairShortestPath::printVertexShortestPath(int sourceVertex) {
    if (sourceVertex >= shortestPathArr.size()) {
        cout << "Error: Source vertex out of range!" << endl;
        return;
    }

    cout << "Shortest Paths from Node " << static_cast<char>('A' + sourceVertex)
        << endl;

    for (int i = 0; i < shortestPathArr[sourceVertex].size(); i++) {
        cout << setw(5) << shortestPathArr[sourceVertex][i] << setw(5);

        vector<int> path;
        constructPath(path, sourceVertex, i);

        for (int j = 0; j < path.size(); j++) {
            cout << static_cast<char>('A' + path[j]);
        }
        cout << endl;
    }

    cout << endl;
}

void AllPairShortestPath::constructPath(vector<int>& pathArr, int node1,
                                        int node2) {
    if (nextNodeInPath[node1][node2] == INF) {
        return;
    }

    pathArr.push_back(node1);

    while (node1 != node2) {
        node1 = nextNodeInPath[node1][node2];
        pathArr.push_back(node1);
    }
}

void AllPairShortestPath::printNextNodeMatrix() {
    cout << "Next Nodes Matrix" << endl;

    cout << setw(8) << "";
    for (int i = 0; i < nextNodeInPath.size(); i++) {
        cout << setw(8) << static_cast<char>('A' + i);
    }
    cout << endl;

    for (int i = 0; i < nextNodeInPath.size(); i++) {
        cout << setw(8) << static_cast<char>('A' + i);
        for (int j = 0; j < nextNodeInPath[i].size(); j++) {
            cout << setw(8) << nextNodeInPath[i][j];
        }
        cout << endl;
    }

    cout << endl;
}
