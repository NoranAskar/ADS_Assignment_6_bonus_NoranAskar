/********************************************************************************
 * WARNING: Please do not remove or modify this comment block.
 *
 * Student Information:
 * Name: ______________________________________
 * Student ID: __________________________________
 * Section Number: ______________________________
 *
 * Instructions:
 * - Fill out your name, student ID, and section number above.
 * - This information is mandatory for the submission of your assignment.
 * - Do not modify this file beyond the specified tasks and guidelines.
 *
 ********************************************************************************/
/********************************************************************************
* WARNING: Please do not remove or modify this comment block.
 *
 * Student Information:
 * Name: Noran Askar
 * Student ID: 900213522
 * Section Number: 3
 *
 * Instructions:
 * - Fill out your name, student ID, and section number above.
 * - This information is mandatory for the submission of your assignment.
 * - Do not modify this file beyond the specified tasks and guidelines.
 *
 ********************************************************************************/

#include <Graph.h>
#include <AllPairShortestPath.h>

#include <iostream>
using namespace std;

int main() {
    // Student Task: Implement Finding all pairs shortest paths in a weighted graph program
    // TODO: 1. Create a CPP file and header file for each class.
    // TODO: 2. Read the xlsx files.
    // TODO: 3. Validate your implementation using Sample.txt.

    Graph graph("../Airports14.xlsx");
    cout << "Graph Info:" << endl << "-----------------\n\n";
    cout << "Number of Vertices is " << graph.getVertexCount() << endl;
    cout << "Number of Edges is " << graph.getEdgeCount() << endl << endl;

    graph.printAdjacencyMatrix();
    graph.printEdges();
    graph.DFS(0);

    AllPairShortestPath graphShortestPaths(graph);
    graphShortestPaths.printAllPairShortestPath();
    graphShortestPaths.printNextNodeMatrix();
    graphShortestPaths.printVertexShortestPath(0);

    return 0;
}